﻿
/****** jtipajax ******/
/*

$(document).ready(function() {
    $('a.jtipajax').each(function() {
        $(this).qtip({
            content: {
                url: '/Handler/ToolTips.ashx?Url=' + encodeURIComponent($(this).attr('href')),
                method: 'get'
            },
            hide: { fixed: true },
            style: { tip: 'topLeft', name: 'cream', color: '#333333', width: 350, border: { width: 2, radius: 2} },
            position: {
                corner: { target: 'bottomLeft', tooltip: 'topLeft' },
                target: 'mouse',
                adjust: { screen: true, mouse: false, y: 5 }

            }
        });
    });
    $('a.jtipajax-donwload').each(function() {
        $(this).qtip({
            content: {
                url: '/Handler/ToolTipDownload.ashx?Url=' + encodeURIComponent($(this).attr('href')),
                method: 'get'
            },
            style: { tip: 'topLeft', name: 'cream', color: '#333333', width: 350, border: { width: 2, radius: 2} },
            position: {
                corner: { target: 'bottomLeft', tooltip: 'topLeft' },
                target: 'mouse',
                adjust: { screen: true }
            }
        });
    });
    $('a.tip-no-ajax').each(function() {
        $(this).qtip({
            content: $(this).attr('tooltip'),
            style: { tip: 'topLeft', name: 'cream', color: '#333333', width: 350, border: { width: 2, radius: 2} },
            position: {
                corner: { target: 'bottomLeft', tooltip: 'topLeft' },
                target: 'mouse',
                adjust: { screen: true }
            }
        });
    });
});
*/

function qtip_form(selector) {
    $(document).ready(function() {
        $(selector).qtip({
            content: { text: false },
            style: { 'font-size': '11px', 'color': '#333333', 'background': '#ffffff url(/app_themes/press/images/tooltipbg.gif) repeat-x left bottom', border: { color: '#aaa'} },
            position: {
                corner: { target: 'bottomLeft', tooltip: 'topMiddle' },
                adjust: { y: 10 }
            }
        });
    });
};

hs.graphicsDir = '/js/highslide/hs-graphics/';
hs.showCredits = false;

function pr_getImageUrl(width, height, fit, clip, file) {
    if (file) {
        if (file.indexOf('http://') == 0) return file;
        return '/handler/ImageResizer.ashx?width=' + width +
        '&height=' + height + '&fit=' + (fit ? '1' : '0') +
        '&clip=' + clip + '&file=' + encodeURIComponent(file);
    } else {
        return null;
    }
}

function pr_build_album_portrait(albumId, options) {
    var opt = {
        navigationWidth: 130,
        thumbSize: 50,
        imageWidth: 409,
        delay: 4000,
        numThumbs: 10
    };
    $.extend(opt, options);

    $ul = $('<ul class="thumbs noscript"></ul>');
    $(opt.images).each(function(index, item) {
        $li = $('<li>').append(
            $('<a>').addClass('thumb').attr('href', pr_getImageUrl(opt.imageWidth, 0, true, 0, item.image))
                .attr('title', item.title ? item.title : '').append(
                    $('<img>').attr('src', pr_getImageUrl(opt.thumbSize, opt.thumbSize, true, 2, item.thumb ? item.thumb : item.image))
                        .attr('alt', item.title ? item.title : ''))).appendTo($ul);
        if (item.title || item.desc) {
            $caption = $('<div>').addClass('caption');
            if (item.title) $caption.append($('<div>').addClass("image-title").text(item.title));
            if (item.desc) $caption.append($('<div>').addClass("image-desc").text(item.desc));
            $caption.appendTo($li);
        }
    });

    $nav = $('<div>').attr('id', albumId + '-thumbs').addClass('navigation').append($ul);
    $content = $('<div>').attr('id', albumId + '-gallery').addClass('content');
    $content.append($('<div>').attr('id', albumId + '-controls').addClass('controls'));
    $content.append($('<div>').attr('id', albumId + '-loading').addClass('loader'));
    $content.append($('<div>').attr('id', albumId + '-slideshow').addClass('slideshow'));
    $content.append($('<div>').attr('id', albumId + '-caption').addClass('embox'));

    $container = $('#' + albumId);
    $container.append($content);
    $container.append($nav);
    $container.append($('<div>').css('clear', 'both'));

    var albumSelector = '#' + albumId;
    $(albumSelector + ' div.navigation').css({ 'width': opt.navigationWidth + 'px', 'float': 'left' });
    $(albumSelector + ' div.content').css('display', 'block');
    var onMouseOutOpacity = 0.6;
    $(albumSelector + '-thumbs ul.thumbs li')
        .css('opacity', onMouseOutOpacity).hover(function() {
            $(this).not('.selected').fadeTo('fast', 1.0);
        },
        function() {
            $(this).not('.selected').fadeTo('fast', onMouseOutOpacity);
        }
    );

    $(document).ready(function() {
        var galleryAdv = $(albumSelector + '-gallery').galleriffic(albumSelector + '-thumbs', {
            delay: opt.delay,
            numThumbs: opt.numThumbs,
            preloadAhead: 10,
            enableTopPager: true,
            enableBottomPager: true,
            imageContainerSel: albumSelector + '-slideshow',
            controlsContainerSel: albumSelector + '-controls',
            captionContainerSel: albumSelector + '-caption',
            loadingContainerSel: albumSelector + '-loading',
            renderSSControls: true,
            renderNavControls: true,
            playLinkText: 'Trình chiếu',
            pauseLinkText: 'Dừng trình chiếu',
            prevLinkText: '&lsaquo; Trước',
            nextLinkText: 'Tiếp &rsaquo;',
            nextPageLinkText: '&rsaquo;',
            prevPageLinkText: '&lsaquo;',
            enableHistory: false,
            autoStart: false,
            onChange: function(prevIndex, nextIndex) {
                $(albumSelector + '-thumbs ul.thumbs').children()
                    .eq(prevIndex).fadeTo('fast', onMouseOutOpacity).end()
                    .eq(nextIndex).fadeTo('fast', 1.0);
            },
            onTransitionOut: function(callback) {
                $(albumSelector + '-caption').fadeTo('fast', 0.0);
                $(albumSelector + '-slideshow').fadeTo('fast', 0.0, callback);
            },
            onTransitionIn: function() {
                $(albumSelector + '-slideshow').fadeTo('fast', 1.0);
                $(albumSelector + '-caption').fadeTo('fast', 1.0);
            },
            onPageTransitionOut: function(callback) {
                $(albumSelector + '-thumbs ul.thumbs').fadeTo('fast', 0.0, callback);
            },
            onPageTransitionIn: function() {
                $(albumSelector + '-thumbs ul.thumbs').fadeTo('fast', 1.0);
            }
        });
    });
}

function pr_build_album_landscape(albumId, options) {
    var opt = {
        thumbSize: 75,
        imageWidth: 488,
        delay: 4000,
        numThumbs: 6
    };
    $.extend(opt, options);

    $ul = $('<ul class="thumbs noscript"></ul>');
    $(opt.images).each(function(index, item) {
        $li = $('<li>').append(
            $('<a>').addClass('thumb').attr('href', pr_getImageUrl(opt.imageWidth, 0, true, 0, item.image))
                .attr('title', item.title ? item.title : '').append(
                    $('<img>').attr('src', pr_getImageUrl(opt.thumbSize, opt.thumbSize - 20, true, 2, item.thumb ? item.thumb : item.image))
                        .attr('alt', item.title ? item.title : ''))).appendTo($ul);
        if (item.title || item.desc) {
            $caption = $('<div>').addClass('caption');
            if (item.title) $caption.append($('<div>').addClass("image-title").text(item.title));
            if (item.desc) $caption.append($('<div>').addClass("image-desc").text(item.desc));
            $caption.appendTo($li);
        }
    });

    //    $nav = $('<div>').attr('id', albumId + '-thumbs').addClass('navigation');
    //    $('<table border="0" cellpadding="0" cellspacing="0" class="tablenav">' +
    //        '<tr><td class="cell-nav"><a title="Trước" class="nav nav-back" id="' + albumId + '-back"></a></td>' +
    //        '<td class="cell-thumb" id="' + albumId + '-data"></td>' +
    //        '<td class="cell-nav"><a title="Tiếp" class="nav nav-next" id="' + albumId + '-next"></a></td>' +
    //        '</tr></table>').appendTo($nav);

    $nav = $('<div>').attr('id', albumId + '-thumbs').addClass('navigation');
    $('<table border="0" cellpadding="0" cellspacing="0" class="tablenav">' +
        '<tr>' +
        '<td class="cell-thumb" id="' + albumId + '-data"></td>' +
        '</tr></table>').appendTo($nav);

    $content = $('<div>').attr('id', albumId + '-gallery').addClass('content');
    $content.append($('<div>').attr('id', albumId + '-controls').addClass('controls'));
    $content.append($('<div>').attr('id', albumId + '-loading').addClass('loader'));
    $content.append($('<div>').attr('id', albumId + '-slideshow').addClass('slideshow'));

    $container = $('#' + albumId);
    $container.append($content);
    $container.append($('<div>').attr('id', albumId + '-caption').addClass('embox'));
    $container.append($nav);
    $container.append($('<div>').css('clear', 'both'));

    $('#' + albumId + '-data').append($ul);

    var albumSelector = '#' + albumId;
    $(albumSelector + ' div.content').css('display', 'block');
    $(albumSelector + ' div.embox').css('display', 'block');

    var onMouseOutOpacity = 0.6;
    var totalPhotos = $(albumSelector + '-thumbs ul.thumbs li').length;
    $(albumSelector + '-thumbs ul.thumbs li').css('opacity', onMouseOutOpacity)
        .hover(function() {
            $(this).not('.selected').fadeTo('fast', 1.0);
        },
        function() {
            $(this).not('.selected').fadeTo('fast', onMouseOutOpacity);
        }
    );

    $(document).ready(function() {
        var galleryAdv = $(albumSelector + '-gallery').galleriffic(albumSelector + '-thumbs', {
            delay: opt.delay,
            numThumbs: opt.numThumbs,
            preloadAhead: 10,
            enableTopPager: false,
            enableBottomPager: true,
            imageContainerSel: albumSelector + '-slideshow',
            controlsContainerSel: albumSelector + '-controls',
            captionContainerSel: albumSelector + '-caption',
            loadingContainerSel: albumSelector + '-loading',
            renderSSControls: true,
            renderNavControls: true,
            playLinkText: 'Trình chiếu',
            pauseLinkText: 'Dừng trình chiếu',
            prevLinkText: '&lsaquo; Trước',
            nextLinkText: 'Tiếp &rsaquo;',
            nextPageLinkText: '&rsaquo;',
            prevPageLinkText: '&lsaquo;',
            enableHistory: false,
            autoStart: false,
            onChange: function(prevIndex, nextIndex) {
                $(albumSelector + '-thumbs ul.thumbs').children()
                    .eq(prevIndex).fadeTo('fast', onMouseOutOpacity).end()
                    .eq(nextIndex).fadeTo('fast', 1.0);
                $(albumSelector + '-next').attr('href', '#' + (nextIndex < totalPhotos - 1 ? nextIndex + 1 : 0));
                $(albumSelector + '-back').attr('href', '#' + (nextIndex > 0 ? nextIndex : totalPhotos - 1));
				pageTracker._trackPageview('/tin-anh'); 
            },
            onTransitionOut: function(callback) {
                $(albumSelector + '-caption').fadeTo('fast', 0.0);
                $(albumSelector + '-slideshow').fadeTo('fast', 0.0, callback);
            },
            onTransitionIn: function() {
                $(albumSelector + '-slideshow').fadeTo('fast', 1.0);
                $(albumSelector + '-caption').fadeTo('fast', 1.0);
            },
            onPageTransitionOut: function(callback) {
                $(albumSelector + '-thumbs ul.thumbs').fadeTo('fast', 0.0, callback);
            },
            onPageTransitionIn: function() {
                $(albumSelector + '-thumbs ul.thumbs').fadeTo('fast', 1.0);
            }
        });

        $(albumSelector + '-next').click(function(ev) {
            $(albumSelector + '-controls a.next').trigger('click');
            return false;
        });

        $(albumSelector + '-back').click(function(ev) {
            $(albumSelector + '-controls a.prev').trigger('click');
            return false;
        });
    });
}

function pr_setup_highslide(group, options) {

    hs.addSlideshow({
        slideshowGroup: group,
        interval: 4000,
        repeat: true,
        useControls: true,
        fixedControls: 'fit',
        overlayOptions: {
            opacity: 0.75,
            position: 'bottom center',
            hideOnMouseOut: true
        }
    });

    var cfg = {
        slideshowGroup: group,
        transitions: ['expand', 'crossfade'],
        outlineType: 'rounded-white',
        fadeInOut: true,
        dimmingOpacity: 0.75,
        numberPosition: 'heading',
        align: 'center'
    };
    hs.extend(cfg, options);
    if (!hs.pr_config) {
        hs.pr_config = new Array();
    }
    hs.pr_config[group] = cfg;
}
function pr_highslide_vote(target, headingText, url,pHeight) {
    var opt = {
        width: 450,
        height:pHeight,
        align: 'center',
        preserveContent: false,
        outlineType: null,
        wrapperClassName: 'pr-popup',
        transitions: ['expand'],
        objectType: 'iframe',
        headingText: headingText,
        headingOverlay: { position: 'top', width: '100%', hideOnMouseOut: false }
    }
    hs.extend(opt, { src: url });
    return hs.htmlExpand(target, opt);
}

function pr_highslide_popup(target, headingText, options) {
    var opt = {
        width: 450,
        align: 'center',
        preserveContent: false,
        outlineType: null,
        wrapperClassName: 'pr-popup',
        transitions: ['expand'],
        objectType: 'iframe',
        headingText: headingText,
        headingOverlay: { position: 'top', width: '100%', hideOnMouseOut: false }
    }
    hs.extend(opt, options);
    return hs.htmlExpand(target, opt);
}

function pr_handle_ajax_error(data) {
    //alert(data.toString());
    alert('Có lỗi xảy ra khi thực hiện yêu cầu, vui lòng thử lại vào lúc khác.');
}

function pr_show_print_version(id_url) {
    var nav_url = id_url.toString();
    var w_print = window.open(id_url, 'article-print', 'width=700,height=500,top=50,left=100,scrollbars=yes', true);
    w_print.focus();
}

function pr_set_rating(articleId, ratingPoint, on_success) {
    MB_PRESSONLINE_WEB.SupportMethods.AddArticleRater(articleId, ratingPoint, on_success, pr_handle_ajax_error);
}

function pr_newsletter_add_subscriber(email, cbl) {

    var txt = document.getElementById(email);

    var tbl = document.getElementById(cbl).childNodes[0];
    if (tbl.childNodes.length == 0) {
        tbl = document.getElementById(cbl).childNodes[1]; // -- firefox
    }
    var sid = '';
    for (var i = 0; i < tbl.childNodes.length; i++) {
        for (var k = 0; k < tbl.childNodes[i].childNodes.length; k++) {
            if (tbl.childNodes[i].childNodes[k].nodeName == "TD") {
                var currentTD = tbl.childNodes[i].childNodes[k];
                for (var j = 0; j < currentTD.childNodes.length; j++) {
                    if (currentTD.childNodes[j].nodeName == "SPAN") {
                        var currentSpan = currentTD.childNodes[j];
                        for (var l = 0; l < currentSpan.childNodes.length; l++) {
                            if (currentSpan.childNodes[l].nodeName == "INPUT" && currentSpan.childNodes[l].type == "checkbox") {
                                var currentChkBox = currentSpan.childNodes[l];
                                if (currentChkBox.checked) {
                                    //alert(currentSpan.title); // -- ie
                                    //alert(currentSpan.Attributes);
                                    sid += currentSpan.title + ',';
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    MB_PRESSONLINE_WEB.SupportMethods.AddNewsletterSubscriber(txt.value, sid, on_success_subscriber, pr_handle_ajax_error);

    return false;
}

function pr_toggle_inline_iframe(containerId, options) {
    var opt = { url: 'about:blank', onShowed: null, onHide: null, width: '100%', scrolling: 'no' };
    $.extend(opt, options);
    var iframeId = containerId + '-ifr';
    if ($('#' + iframeId).length > 0) {
        $('#' + iframeId).slideUp('fast', function() { $(this).remove() });
        $('#' + containerId).hide();
        if ($.isFunction(opt.onHide)) onHide();
        return;
    }
    $iframe = $('<iframe>').attr('id', iframeId)
        .attr('width', opt.width).attr('height', '1px')
        .attr('frameborder', '0').attr('scrolling', opt.scrolling)
        .attr('marginheight', '0').attr('marginwidth', '0');
    $('#' + containerId).append('<div style="padding: 5px">Vui lòng chờ...</div>').show();
    $('#' + containerId).append($iframe).show();
    $('#' + iframeId).load(function(e) {
        $('#' + containerId).find('div').remove();
        var t = e.target;
        var height = e.target.contentDocument ? $(e.target.contentDocument.body).height() : e.target.contentWindow.document.body.scrollHeight;
        $(e.target).css("display", "none");
        e.target.height = (height + 0) + 'px';
        $(e.target).slideDown('fast');
        if ($.isFunction(opt.onShowed)) opt.onShowed(e.target);
    });
    $iframe.attr('src', opt.url);
}

/**************************** Utilities *******************************************/

function adjustTextSize(elId, Step) {
    var el = document.getElementById(elId);
    var num = parseInt(el.style.fontSize);
    if (isNaN(num)) num = 13;
    num += Step;
    if (num > 20) num = 20;
    if (num < 9) num = 9;
    el.style.fontSize = (num + "px");
}

function getMouseXY(e) {
    var posx = 0;
    var posy = 0;
    if (!e) var e = window.event;
    if (e.pageX || e.pageY) {
        posx = e.pageX;
        posy = e.pageY;
    }
    else if (e.clientX || e.clientY) {
        posx = e.clientX + document.body.scrollLeft
			+ document.documentElement.scrollLeft;
        posy = e.clientY + document.body.scrollTop
			+ document.documentElement.scrollTop;
    }
    return { left: posx, top: posy };
}

function getScrollXY() {
    var scrOfX = 0, scrOfY = 0;
    if (typeof (window.pageYOffset) == 'number') {
        //Netscape compliant
        scrOfY = window.pageYOffset;
        scrOfX = window.pageXOffset;
    } else if (document.body && (document.body.scrollLeft || document.body.scrollTop)) {
        //DOM compliant
        scrOfY = document.body.scrollTop;
        scrOfX = document.body.scrollLeft;
    } else if (document.documentElement && (document.documentElement.scrollLeft || document.documentElement.scrollTop)) {
        //IE6 standards compliant mode
        scrOfY = document.documentElement.scrollTop;
        scrOfX = document.documentElement.scrollLeft;
    }
    return [scrOfX, scrOfY];
}

function getInnerSize() {
    var myWidth = 0, myHeight = 0;
    if (typeof (window.innerWidth) == 'number') {
        //Non-IE
        myWidth = window.innerWidth;
        myHeight = window.innerHeight;
    } else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        //IE 6+ in 'standards compliant mode'
        myWidth = document.documentElement.clientWidth;
        myHeight = document.documentElement.clientHeight;
    } else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
        //IE 4 compatible
        myWidth = document.body.clientWidth;
        myHeight = document.body.clientHeight;
    }
    return [myWidth, myHeight];
}


function ScrollToElement(theElement, offsetX, offsetY) {

    var selectedPosX = 0;
    var selectedPosY = 0;

    while (theElement != null) {
        selectedPosX += theElement.offsetLeft;
        selectedPosY += theElement.offsetTop;
        theElement = theElement.offsetParent;
    }

    window.setTimeout("window.scrollTo(" + (selectedPosX + (offsetX ? offsetX : 0)) + "," + (selectedPosY + (offsetY ? offsetY : 0)) + ")", 100);

}
function GetCenteredXY(w, h) {
    var ps = getScrollXY();
    var sz = getInnerSize();
    var Left = (sz[0] - w) / 2 + ps[0];
    var Top = (sz[1] - h) / 2 + ps[1];
    return [Math.ceil(Left), Math.ceil(Top)];
}
calendar__days = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy", "Chủ nhật"];
calendar__daysShort = ["CN", "Hai", "Ba", "Tư", "Năm", "Sáu", "Bảy", "CN"];
calendar__daysMin = ["CN", "T2", "T3", "T4", "T5", "T6", "T7", "CN"];
calendar__months = ["Thg Giêng", "Thg Hai", "Thg Ba", "Thg Tư", "Thg Năm", "Thg Sáu", "Thg Bảy", "Thg Tám", "Thg Chín", "Thg Mười", "Thg Mười Một", "Thg Mười Hai"];
calendar__monthsShort = ["Thg 1", "Thg 2", "Thg 3", "Thg 4", "Thg 5", "Thg 6", "Thg 7", "Thg 8", "Thg 9", "Thg 10", "Thg 11", "Thg 12"];

function SetupDatePicker(selector, options) {
    jQuery(selector).DatePicker({
        format: 'd/m/Y',
        position: 'bottom',
        date: $(selector).val(),
        current: $(selector).val(),
        locale: {
            days: calendar__days,
            daysShort: calendar__daysShort,
            daysMin: calendar__daysMin,
            months: calendar__months,
            monthsShort: calendar__monthsShort
        },
        onBeforeShow: function() {
            $('selector').DatePickerSetDate($(selector).val(), true);
        },
        onChange: function(formated, dates) {
            $(selector).val(formated);
            $(selector).DatePickerHide();
        }
    });
}

function ads_openLinkPopup(url, name, arrProperty) {
    var newwindow;
    newwindow = window.open(url, name, arrProperty)
    if (window.focus) {
        newwindow.focus()
    }
}
//sondt
function on_success(result) {
    alert("ok");
    return false;
}
function ads_openPopupWithContent(name, header, adID, pHeight, pWidth) {
    var parms = "width=" + pWidth + ",height=" + pHeight + ",menubar=no,location=no,scrollbars";
    var newwindow2 = window.open('#', name, parms);
    MB_PRESSONLINE_WEB.SupportMethods.GetAdsPopupContent(adID,
        function(data) {
            var tmp = newwindow2.document;
            tmp.write('<html><head><title>' + header + '</title>');
            tmp.write('</head><body>' + data.toString());
            tmp.write('<p><a href="javascript:self.close()">[ Đóng lại ]</a></p>');
            tmp.write('</body></html>');
            tmp.close();
        }, pr_handle_ajax_error);
    }
    
/*SiteTopStories*/
function SiteTopStories_Galleriffic() {
    // We only want these styles applied when javascript is enabled
    $('div.navigation').css({ 'width': '65px', 'float': 'right' });
    $('div.content').css('display', 'block');

    // Initially set opacity on thumbs and add
    // additional styling for hover effect on thumbs
    var onMouseOutOpacity = 0.5;
    $('#thumbs ul.thumbs li').css('opacity', onMouseOutOpacity).hover(function() { $(this).not('.selected').fadeTo('fast', 1.0); }, function() { $(this).not('.selected').fadeTo('fast', onMouseOutOpacity); });
    $(document).ready(function() {
        $("div.sts-cap").show();
        // Initialize Advanced Galleriffic Gallery
        var galleryAdv = $('#gallery').galleriffic('#thumbs', {
            delay: 3000,
            numThumbs: 12,
            preloadAhead: 10,
            enableTopPager: true,
            enableBottomPager: true,
            imageContainerSel: '#slideshow',
            controlsContainerSel: '#controls',
            captionContainerSel: '#caption',
            loadingContainerSel: '#loading',
            renderSSControls: false,
            renderNavControls: true,
            playLinkText: 'Play Slideshow',
            pauseLinkText: 'Pause Slideshow',
            prevLinkText: '&lsaquo; Previous Photo',
            nextLinkText: 'Next Photo &rsaquo;',
            nextPageLinkText: 'Next &rsaquo;',
            prevPageLinkText: '&lsaquo; Prev',
            enableHistory: false,
            autoStart: true,
            onChange: function(prevIndex, nextIndex) {
                $('#thumbs ul.thumbs').children().eq(prevIndex).fadeTo('fast', onMouseOutOpacity).end().eq(nextIndex).fadeTo('fast', 1.0);
                advancelink_Click();
            },
            onTransitionOut: function(callback) {
                $('#caption').fadeTo('fast', 0.0);
                $('#slideshow').fadeTo('fast', 0.0, callback);
                advancelink_Click();
            },
            onTransitionIn: function() {
                $('#slideshow').fadeTo('fast', 1.0);
                $('#caption').fadeTo('fast', 1.0);
                advancelink_Click();
            },
            onPageTransitionOut: function(callback) {
                $('#thumbs ul.thumbs').fadeTo('fast', 0.0, callback);
                advancelink_Click();
            },
            onPageTransitionIn: function() {
                $('#thumbs ul.thumbs').fadeTo('fast', 1.0);
                advancelink_Click();
            }
        });
    });
    function advancelink_Click() {
        $("a.advance-link").click(function() {
            window.location = $("div.image-desc-1 a.-title").attr("href");
        });
    }
}
/*ArticleTabbedBox*/
function DisplayTip(contentId) {
    $('#' + contentId + ' a.jtipajax').each(function() {
        $(this).qtip({
            content: {
                url: '/Handler/ToolTip.ashx?Url=' + encodeURIComponent($(this).attr('href')),
                method: 'get'
            },
            style: { tip: 'topLeft', name: 'cream', color: '#333333', width: 350, border: { width: 2, radius: 2} },
            position: {
                corner: { target: 'bottomLeft', tooltip: 'topLeft' },
                target: 'mouse'
            }
        });
    });
}
function ArticleTabbedTab(tabHeaderFistId, tabHeaderSepId, tabHeaderNameId, contentId, IdList, dvPanel, ulTab) {
    $(document).ready(function() {
        $(contentId).html("<div class='art-tab-loader'></div>");
        var fistKey = $(tabHeaderFistId).attr("key");
        var getFistMsg = '';
        $.ajax({ type: "GET",
            url: "/RenderArticleTabbedBox.aspx?key=" + fistKey + "&name=null&IdList=" + IdList + "&rnd=" + Math.random(),
            success: function(msg) {
                $(contentId).html(msg);
                //DisplayTip(contentId);
                getFistMsg = msg;
            }
        });
        $(tabHeaderFistId).click(function() {
            $(contentId).html(getFistMsg);
            //DisplayTip(contentId);
            $(tabHeaderNameId).each(function(idx1) {
                $(this).removeClass("tab-selected");
            });
        });
        //$(tabHeaderSepId).each(function(idx) { if (idx == 0) $(this).addClass("hide"); });
        $(tabHeaderNameId).each(function(idx) {
            $(this).click(function() {
                $(tabHeaderNameId).each(function(idx1) {
                    $(this).removeClass("tab-selected");
                });
                $(this).addClass("tab-selected");
                var key = $(this).attr("key");
                var name = $(this).attr("name");
                $(contentId).html("<div class='art-tab-loader'></div>");
                $.ajax({ type: "GET",
                    url: "/RenderArticleTabbedBox.aspx?key=" + key + "&name=" + name + "&IdList=" + IdList + "&rnd=" + Math.random(),
                    success: function(msg) {
                        $(contentId).html(msg);
                        //DisplayTip(contentId);
                    }
                });
            });
        });
        var div = $(dvPanel), ul = $(ulTab), ulPadding = 20;
        var divWidth = div.width();
        div.css({ overflow: 'hidden' });  //Find last image container
        var lastLi = ul.find('li:last-child');  //When user move mouse over menu
        div.mousemove(function(e) {
            var ulWidth = (lastLi[0].offsetLeft + lastLi.outerWidth() + ulPadding);
            var left = (e.pageX - div.offset().left) * (ulWidth - divWidth) / divWidth;
            div.scrollLeft(left);
        });
    });
}

/***gia moi***/
function renderGiamoiBox(divContent, ulPager, firstPageSelected, pageIndex, urlRedirect, 
                        imgWith, imgHeight, pageSize, repeatColumn) {
    $(document).ready(function() {

        $(divContent).html("<div class='art-tab-loader' style='height:220px;'></div>");
        var getFistMsg = '';
        $.ajax({ type: "GET",
        url: urlRedirect + "?pIndex=" + pageIndex + "&pSize=" + pageSize + "&imW=" + imgWith + "&imH=" + imgHeight + "&numCol=" + repeatColumn + "&rnd=" + Math.random(),
            success: function(msg) {
                $(divContent).html(msg);
                //DisplayTip(divContent);
                getFistMsg = msg;
            }
        }); // end 1

        $(firstPageSelected).click(function() {
            $(divContent).html(getFistMsg);
            //DisplayTip(divContent);
            $(ulPager).each(function(idx1) {
                $(this).removeClass("selected");
            });
        }); // end 2

        var gm_other = '';
        $(ulPager).each(function(idx) {
            $(this).click(function() {
                $(ulPager).each(function(idx1) {
                    $(this).removeClass("selected");
                });
                $(this).addClass("selected");
                
                var key = $(this).attr("key");
                
                $(divContent).html("<div class='art-tab-loader' style='height:220px;'></div>");
                $.ajax({ type: "GET",
                url: urlRedirect + "?pIndex=" + key + "&pSize=" + pageSize + "&imW=" + imgWith + "&imH=" + imgHeight + "&numCol=" + repeatColumn + "&rnd=" + Math.random(),
                    success: function(msg) {
                        $(divContent).html(msg);
                        //DisplayTip(divContent);
                        gm_other = msg;
                    }
                });
            });
        }); // end 3

    });
}


/***event list***/
function render_event_list(divContent, pageIndex, pageSize) {

    $(document).ready(function() {
        
        $(divContent).html("<div class='art-tab-loader' style='height:220px;'></div>");
        var getFistMsg = '';
        $.ajax({ type: "GET",
            url: "/Controls/render-page/render-lich-sukien.aspx?p=" + pageIndex + "&ps=" + pageSize +
                 "&rnd=" + Math.random(),
            success: function(msg) {
                $(divContent).html(msg);
            }
        }); // end 1
    });
}
function render_calendar(divContent, month, year) {
    $(document).ready(function() {
        $(divContent).html("<div class='art-tab-loader' style='height:180px;'></div>");
        var getFistMsg = '';
        $.ajax({ type: "GET",
            url: "/Controls/render-page/render-calendar.aspx?month=" + month + "&year=" + year + "&rnd=" + Math.random(),
            success: function(msg) {
                $(divContent).html(msg);
            }
        }); // end 1
    });
}

/*CarrersList*/
function overlib(str) { }
function nd() { }
function Carrers_Marquee() {
    $(document).ready(function() {
        $.ajax({ type: "GET",
            url: "/RendeJobList.aspx?rnd=" + Math.random(),
            success: function(msg) { $("#ct_carrers_list").html(msg); }
        });
        $('#marquee marquee').marquee('pointer').mouseover(function() {
            $(this).trigger('stop');
        }).mouseout(function() {
            $(this).trigger('start');
        });
    });
}
/*SearchBoxAndLoginBox*/
function SearchOnFocus(field) {
    if (field.value == 'Từ khóa tìm kiếm') { field.value = ''; }
}

function SearchOnBlur(field) {
    if (field.value == '') { field.value = 'Từ khóa tìm kiếm'; }
}
function CheckValue(ctId) {
    var st = document.getElementById(ctId);
    if (st.value == 'Từ khóa tìm kiếm' || st.value == '') {
        st.focus();
        return false;
    }
    return true;
}
/*SidebarContentMenu*/
/********************/

var 
  adState = [];

function changeAdTimer(ControlInstanceId, PageId, CategoryId, ShowedIds, HoursChange, divId) {
    var caller = adState[ControlInstanceId].caller;
    var AdCode = caller.GetAdCode(true, ControlInstanceId, PageId, CategoryId, ShowedIds, function(response) {
        if (response.error) {
            // if (console) console.log(response.error);
            return;
        }
        var r = response.result.result.AdCode;
        $("#ad-pos-instance-" + ControlInstanceId).html(r);
    });
}

function changeAd(IsAjax, ControlInstanceId, PageId, CategoryId, ShowedIds, HoursChange, divId) {
    if (!adState[ControlInstanceId]) {
        adState[ControlInstanceId] = {
            caller: new AdServerCaller()
        };
    }
    var timerCode = 'changeAdTimer(' + ControlInstanceId + ',"' + PageId + '",' + CategoryId + ',"' + ShowedIds + '","' + divId + '")';
    setTimeout(timerCode, HoursChange * 1000);
}

function js_showhideMenu(showHideDiv, hideDiv, switchImgTag) {
    var ele = document.getElementById(showHideDiv);
    var eleHide = document.getElementById(hideDiv);
    var imageEle = document.getElementById(switchImgTag);
    if (ele.style.display == "block") {
        ele.style.display = "none";
        eleHide.style.display = "block";
    }
    else {
        ele.style.display = "block";
        eleHide.style.display = "none";
    }
}

//function call_GA_Code(path) {
//    var _gaq = _gaq || [];
//    _gaq.push(['_setAccount', 'UA-401587-1']);
//    _gaq.push(['_setDomainName', '.pcworld.com.vn']);
//    _gaq.push(['_trackPageview', path]);

//    (function() {
//        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
//        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
//        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
//    })();
//}


function js_showBackgroundBanner(divId, posDiv, adId) {
    var wh = getInnerSize();
    var divItem = document.getElementById(divId);
    var divWidth = ((wh[0] - 994) / 2);
    divItem.style.height = wh[1] + 'px';
    if (posDiv == 'left')
        divItem.style.left = (wh[0] / 2) - 497 - 230 + 'px';
    else
        divItem.style.right = (wh[0] / 2) - 497 - 230 + 'px';
}

var t;
function JSFX_FloatDiv(divLeft, divRight) {
    var wh = getInnerSize();
    var leftItem = document.getElementById(divLeft);
    var rightItem = document.getElementById(divRight);
    var ns = (navigator.appName.indexOf("Netscape") != -1);
    if (ns) {
        leftItem.style.left = (document.body.clientWidth / 2) - 497 - 222 + 'px';
        rightItem.style.right = (document.body.clientWidth / 2) - 497 - 222 + 'px';
    }
    else {
        leftItem.style.left = (document.documentElement.clientWidth / 2) - 497 - 230 + 'px';
        rightItem.style.right = (document.documentElement.clientWidth / 2) - 497 - 230 + 'px';
    }
    t = setTimeout("JSFX_FloatDiv('" + divLeft + "','" + divRight + "');", 0);
}

function runResize(divLeft, divRight) {
    window.onresize = function() { JSFX_FloatDiv(divLeft, divRight); }
}

function countAdClick(url) {
    ads_openLinkPopup(url,'');
}

/*******
    Danh cho quang cao o goc phai man hinh
*************************************************************************************************************************/
function js_action_adbottom(action) {
     var browserInnerSize = getInnerSize();
     var adbottomBox = $("#adbottom-form");
     // minisize
     if (action == "min") {
         $("#ad-bottom-content").height(0);
         adbottomBox.css("top",browserInnerSize[1]-30);
     }
     // max size
     if (action == "max") {
         $("#ad-bottom-content").height(250);
         adbottomBox.css("top", browserInnerSize[1] - 287);
     }
     //close
     if (action == "close") {
         adbottomBox.css("display","none");
     }
 }


 /*******
    Thuat ngu
 *************************************************************************************************************************/
 //sondt
 function js_findWord(vWord, divTNContainer, divContent, ctrWidth) {
     var divContent = $("div#" + divContent);
     var divContainer = $("div#" + divTNContainer);
     
     if (vWord.length == 0) {
         divContainer.css("visibility", "hidden");
         return false;
     }

     divContent.html("<div class='art-tab-loader'></div>");
     var pos = divContent.position();    
     
     divContent.addClass("thuat-ngu");
     divContainer.addClass("thuat-ngu-container");

     divContainer.css("visibility", "visible");
     divContainer.css("top", pos[0]);
     divContainer.css("width", ctrWidth);

     MB_PRESSONLINE_WEB.SupportMethods.FindWord(vWord, function(data) {
         divContent.html(data);
     }, pr_handle_ajax_error);
     return false;
 }

 function js_showMeaning(val, pWidth, pHeight) {
     var parms = "width=430,height=400,menubar=no,location=no,scrollbars";
     var url = "/controls/render-page/thuatngu-content.aspx?gId=" + val;
     var newwindow2 = window.open(url, 'PCWORLDVN-Thuatngu', parms);
     newwindow2.focus();
 }
 
 function LoggingAD(strAdID){
	var cs_polyad_url = "http://pcworld.com.vn/loggingad.aspx?strAdID="+ strAdID + "&r=" + Math.random();
	$.get(cs_polyad_url, function(data) {
	  //$('.result').html(data);
	  //alert('Load was performed.');
	});
    
    //$.ajax(cs_polyad_url);
}